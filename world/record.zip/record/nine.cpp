#include<vector>
#include<sstream>
#include<iostream>
#include<string>
#include<fstream>
#include<numeric> //accumulate
using namespace std;

vector<string> split(string& input, char delimiter){
  istringstream stream(input);
  string field;
  vector<string> result;
  while(getline(stream, field, delimiter)){
    result.push_back(field);
  }
  return result;
}

int main(int argc, char* argv[]){
  ifstream scan(argv[1]); //$B85%G!<%?(B
  bool top_s = 1,top_o = 1;
  string line_s,line_o;
  vector<string> laser_s;
  vector<long> time_s,time_o;
  long double n,temp = 0.0;
  vector<long int> n1,n2,n3,n4,n5,n6,n7,n8,n9;
  vector<long double> laser,ang,a;
  //odo$B%G!<%?$N=hM}(B
  ifstream odo(argv[3]); //$B85%G!<%?(B
  while(getline(odo,line_o)){
    if(top_o == 1) {
      top_o = 0;
    }
    else{
      vector<string>vec=split(line_o,',');
      time_o.push_back(stol(vec[0]));
      ang.push_back(stold(vec[6]));
    }
  }
  ofstream ofs_o(argv[4]);
  for(int k = 0;k < time_o.size();k++){
    temp += ang[k];
    a.push_back(temp); 
    ofs_o<<time_o[k]<<","<<ang[k]<<","<<a[k]<<endl;
  }
     
  //scan$B%G!<%?$N=hM}(B
  while(getline(scan,line_s)){
    if(top_s == 1) { //1$B9TL\$ONsL>$J$N$GHt$P$9(B
      top_s = 0;
    }
    else{ //$B?tCM%G!<%?(B
      vector<string>strvec=split(line_s,','); //$BJ8;zNs$H$7$F<u$1<h$k(B
      time_s.push_back(stol(strvec[0])); //$B;~4V(B
      laser_s.resize(1010); //core damp$BM=KI(B
      copy(strvec.begin()+14, strvec.begin()+1022, laser_s.begin()); //$B%l!<%6!<%G!<%?$N$_(B
      //laser.resize(1010);
      for(int i = 0;i < 1008;i++){
        laser.push_back(stold(laser_s[i])); //$B%l!<%6!<%G!<%?$rJ8;zNs$+$i>.?t$KJQ49(B
        switch(i){
          case 111:
            n = accumulate(laser.begin(), laser.begin()+112,0.0); //20$BEY$4$H$K%G!<%?$r9g7W(B
            n1.push_back(n/112*1000); //$BJ?6Q$7$FC10LJQ49(B
            break;
          case 223:
            n = accumulate(laser.begin()+112, laser.begin()+224,0.0);
            n2.push_back(n/112*1000);
            break;
          case 335:
            n = accumulate(laser.begin()+224, laser.begin()+336,0.0); 
            n3.push_back(n/112*1000);
            break;
          case 447:
            n = accumulate(laser.begin()+336, laser.begin()+448,0.0);
            n4.push_back(n/112*1000);
            break;
          case 559:
            n = accumulate(laser.begin()+448, laser.begin()+560,0.0); 
            n5.push_back(n/112*1000);
            break;
          case 671:
            n = accumulate(laser.begin()+560, laser.begin()+672,0.0);
            n6.push_back(n/112*1000);
            break;
          case 783:
            n = accumulate(laser.begin()+672, laser.begin()+784,0.0); 
            n7.push_back(n/112*1000);
            break;
          case 895:
            n = accumulate(laser.begin()+784, laser.begin()+896,0.0);
            n8.push_back(n/112*1000);
            break;
          case 1007:
            n = accumulate(laser.begin()+896, laser.begin()+1008,0.0);
            n9.push_back(n/112*1000);
            break;
        }
      }
      laser.clear(); 
    } //else
  } //while
  ofstream ofs(argv[2]);
  for(int j = 0;j < time_s.size();j++){
    ofs<<time_s[j]<<","<<n1[j]<<","<<n2[j]<<","<<n3[j]<<","<<n4[j]<<","<<n5[j]<<","<<n6[j]<<","<<n7[j]<<","<<n8[j]<<","<<n9[j]<<endl;
  }
return 0;
} //main

